# Judge Model Information

**Model**: claude-sonnet-4-5-20250929
**Claude Code Version**: 2.1.12 (Claude Code)
**Timestamp**: 2026-01-20T06:16:05.747468+00:00
