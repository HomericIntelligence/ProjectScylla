Complete this task using available tools and your best judgment.

## Cleanup Requirements

- Remove any temporary files created during task completion (build artifacts, cache files, etc.)
- Clean up after yourself - the workspace should contain only final deliverables
