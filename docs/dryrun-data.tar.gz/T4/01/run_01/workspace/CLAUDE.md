Use the following sub-agent to solve this task:

- chief-architect

## Cleanup Requirements

- Remove any temporary files created during task completion (build artifacts, cache files, etc.)
- Clean up after yourself - the workspace should contain only final deliverables
