# Table 7: Full Subtest Results (Appendix B)

| Model | Tier | Subtest | Pass Rate | Mean Score | Std Dev | Cost ($) | Modal Grade | Grade Distribution |
|-------|------|---------|-----------|------------|---------|----------|-------------|-------------------|
| Sonnet 4.5 | T0 | 00 | 1.000 | 0.973 | nan | 0.1351 | A | S:0 A:1 B:0 C:0 D:0 F:0 |
| Sonnet 4.5 | T1 | 01 | 1.000 | 0.970 | nan | 0.1274 | A | S:0 A:1 B:0 C:0 D:0 F:0 |
| Sonnet 4.5 | T2 | 01 | 1.000 | 0.983 | nan | 0.1380 | A | S:0 A:1 B:0 C:0 D:0 F:0 |
| Sonnet 4.5 | T3 | 01 | 1.000 | 0.983 | nan | 0.1294 | A | S:0 A:1 B:0 C:0 D:0 F:0 |
| Sonnet 4.5 | T4 | 01 | 1.000 | 0.960 | nan | 0.1685 | A | S:0 A:1 B:0 C:0 D:0 F:0 |
| Sonnet 4.5 | T5 | 01 | 1.000 | 0.983 | nan | 0.0653 | A | S:0 A:1 B:0 C:0 D:0 F:0 |
| Sonnet 4.5 | T6 | 01 | 1.000 | 0.943 | nan | 0.2474 | A | S:0 A:1 B:0 C:0 D:0 F:0 |
