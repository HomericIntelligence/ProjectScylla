# Table 9: Experiment Configuration

| Experiment | Agent Models | Tiers | Tier IDs | Subtests/Tier | Runs/Subtest | Total Runs | Judge Models |
|------------|--------------|-------|----------|---------------|--------------|------------|--------------|
| 2026-01-20T06-13-07-test-001 | Sonnet 4.5 | 7 | T0, T1, T2, T3, T4, T5, T6 | 1 | 1 | 7 | N/A |
