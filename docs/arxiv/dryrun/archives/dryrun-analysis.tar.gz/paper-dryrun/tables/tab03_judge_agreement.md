# Table 3: Judge Agreement

| Judge Pair | Spearman ρ | Pearson r | Mean |Δ Score| |
|------------|------------|-----------|---------------|
| Judge 1 – Judge 2 | 0.333 | 0.706 | 0.0329 |
| Judge 1 – Judge 3 | -0.273 | -0.063 | 0.0445 |
| Judge 2 – Judge 3 | -0.522 | -0.347 | 0.0373 |
| All Judges (Overall) | nan | nan | nan |

**Krippendorff's α** (interval): -0.117
