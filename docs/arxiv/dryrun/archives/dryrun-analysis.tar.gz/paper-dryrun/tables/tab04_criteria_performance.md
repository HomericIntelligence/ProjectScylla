# Table 4: Per-Criteria Performance

| Criterion | Weight | Sonnet 4.5 Mean (±σ) | p-value | Winner |
|----------|----------|----------|----------|
| functional | 0.35 | 1.000 ± 0.000 | — | — |
| code_quality | 0.20 | 1.000 ± 0.000 | — | — |
| proportionality | 0.15 | 0.940 ± 0.083 | — | — |
| build_pipeline | 0.10 | 1.000 ± 0.000 | — | — |
| overall_quality | 0.20 | 0.975 ± 0.039 | — | — |
