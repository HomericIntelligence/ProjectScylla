#!/bin/bash
# Worktree: T4_01_run_01 @ /home/mvillmow/fullruns/test001-dryrun/2026-01-20T06-13-07-test-001/T4/01/run_01/workspace
git -C /home/mvillmow/fullruns/test001-dryrun/2026-01-20T06-13-07-test-001/repo worktree add -b T4_01_run_01 /home/mvillmow/fullruns/test001-dryrun/2026-01-20T06-13-07-test-001/T4/01/run_01/workspace 7fd1a60b01f91b314f59955a4e4d4e80d8edf11d
